import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nofication',
  templateUrl: './nofication.component.html',
  styleUrls: ['./nofication.component.css']
})
export class NoficationComponent implements OnInit {

  constructor(){}

  ngOnInit(): void {
  }

  displayNotification: boolean = false;

  closeNotification(){
    this.displayNotification = true;
  }

}

