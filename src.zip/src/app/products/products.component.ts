import { Component } from '@angular/core';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent {

  products = [
    {id:1, name:'Analog Watch', price: '199', color:'Black', available:'Available', image:'assets/img1.png'},
    {id:2, name:'Smart Led TV', price: '3499', color:'Black', available:'Available', image:'assets/img2.png'},
    {id:3, name:'Android Phone', price: '14999', color:'Black', available:'Not Available', image:'assets/img3.png'},
    {id:4, name:'Washing Machine', price: '7999', color:'Black', available:'Available', image:'assets/img4.png'},
    {id:5, name:'Refrigrator', price: '13999', color:'Red', available:'Not  Available', image:'assets/img5.png'},
    {id:6, name:'Electric Iron', price: '899', color:'Blue & White', available:'Available', image:'assets/img6.png'}
  ]

}
